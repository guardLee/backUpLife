#!/usr/bin/env bash
# copyrightⓒ 2022 All rights reserved by SungJae, Yun. (sjyun@cloudgram.com)

DATE=`date +%Y-%m-%d_%H:%M:%S`

usage () {
	echo ""
    echo "usage: $0 {user_name} "
    echo "-. Add Application user"
    echo "-. Mount DISK (/svc)"
    echo "-. Install GCP Ops Agent"
    echo ""
    echo "example: sudo $0 testadm"
    echo ""
}

if [ -z $1 ]
then
    usage
    exit
fi

sudo yum -y update
sudo yum -y install redhat-lsb wget nmon nfs-utils expect



# Add Application User 
############### Add Application user ###################
echo ""
echo "////////////////////////////////////////"
echo "***** application user 추가 *****"
USER=$1
PASSWORD="!admin1234"
    sudo useradd -m $USER
    sudo usermod -G wheel $USER                      ## CentOS에서 sudo 권한 부여
    echo "ID/Password : $USER / !dlatl00"
expect <<EOF
spawn sudo passwd "$USER"
expect "New password:"
send "$PASSWORD\r";

expect "Retype new password:"
send "$PASSWORD\r";

expect eof 
EOF



############### Mount DISK ###################
DEVICE_NAME="sdb"

sudo lsblk
echo ""
echo "If you cannot find /dev/sdb, STOP !!!"
read -p " Press any key to continue ..."
echo ""

echo ""
echo "////////////////////////////////////////"
echo "1. FORMAT /dev/sdb"
sudo mkfs.ext4 -F -m 0 -E lazy_itable_init=0,lazy_journal_init=0,discard /dev/${DEVICE_NAME}

echo ""
echo "////////////////////////////////////////"
echo "2. /dev/sdb 를 fstab에 등록"
echo "### added $DATE ###" | sudo tee -a /etc/fstab
sudo cp /etc/fstab /etc/fstab.backup.$DATE
#sudo blkid /dev/${DEVICE_NAME}
UUID_VALUE=`sudo blkid /dev/${DEVICE_NAME} -o udev | grep "ID_FS_UUID=" | sed -e "s/ID_FS_UUID=//g"`
echo "UUID=${UUID_VALUE} /svc ext4 discard,defaults 0 2" | sudo tee -a /etc/fstab
echo ""
echo ">>>>>>>>>>>>> CHECK >>>>>>>>>>>>"
cat /etc/fstab
echo ">>>>>>>>>>>>> CHECK >>>>>>>>>>>>"
#read -p " Press any key to continue ..."
echo ""

sudo mkdir /svc
sudo mount -a

# 마운트 포인트 생성 작업
echo ""
echo "////////////////////////////////////////"
echo "3. 마운트 포인트 생성 작업"
sudo mkdir -p /svc/engn001
sudo mkdir -p /svc/logs001
sudo mkdir -p /svc/data001
sudo mkdir -p /svc/sorc001
sudo chown -R $USER.$USER /svc

echo ""
echo ">>>>>>>>>>>>> CHECK >>>>>>>>>>>>"
cat /etc/fstab
echo ""
df -h
echo ""
ls -al /svc
echo ">>>>>>>>>>>>> CHECK >>>>>>>>>>>>"





# Installing GCP Ops Agent 
############### Ops Agent ###################
sudo yum -y update
echo ""
echo "////////////////////////////////////////"
echo "***** Installing GCP Ops Agent *****"
curl -sSO https://dl.google.com/cloudagents/add-google-cloud-ops-agent-repo.sh
sudo bash add-google-cloud-ops-agent-repo.sh --also-install
echo 'GCP Ops Agent Installed.'
