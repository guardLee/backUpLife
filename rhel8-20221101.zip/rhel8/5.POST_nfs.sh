#!/usr/bin/env bash
# copyrightⓒ 2022 All rights reserved by SungJae, Yun. (sjyun@cloudgram.com)

DATE=`date +%Y-%m-%d_%H:%M:%S`

usage () {
    echo ""
    echo "usage: $0 {user_name} {filestore}"
    echo "-. Only used when using Filestore service"
    echo ""
    echo 'example: sudo '$0' testadm 10.85.174.10:/fs/test '
    echo ""
    echo "#############################################################"
    echo "우선 마운트하여 서비스별 서브 디렉토리를 생성하고 진행하세요..."
    echo 'sudo mount 10.85.174.10:/fs /mnt'
    echo 'sudo mkdir /mnt/{project_name}_dev'
    echo 'sudo umount /mnt'
    echo "#############################################################"
    echo ""
}

if [ -z $2 ]
then
        usage
        exit
fi
if [ -z $1 ]
then
        usage
        exit
fi

sudo yum -y install nfs-utils

USER=$1
FILESTORE=$2

# Filestore 접속을 위한 NFS 포트 설정
############### Filestore ###################
echo ""
echo "////////////////////////////////////////"
echo "***** Filestore 접속을 위한 NFS 포트 설정 *****"
echo "### added $DATE ###" | sudo tee -a /etc/sysconfig/nfs
echo "STATD_PORT=2046" | sudo tee -a /etc/sysconfig/nfs
echo "### added $DATE ###" | sudo tee -a /etc/modprobe.d/lock.conf
echo "options lockd nlm_tcpport=4045" | sudo tee -a /etc/modprobe.d/lock.conf
echo "options lockd nlm_udpport=4045" | sudo tee -a /etc/modprobe.d/lock.conf

# NFS Mount. NAS가 필요한 서버들만 진행
############### Filestore ###################
echo ""
echo "////////////////////////////////////////"
echo "***** Filestore MOUNT *****"
echo "### added $DATE ###" | sudo tee -a /etc/fstab
echo "$FILESTORE /svc/nas nfs hard,timeo=600,retrans=3,rsize=1048576,wsize=1048576,resvport,async,_netdev 0 0" | sudo tee -a /etc/fstab
sudo mkdir /svc/nas
sudo mount /svc/nas
sudo chown $USER:$USER /svc/nas


# Filestore 접속을 위한 NFS 포트 설정
############### Filestore ###################
echo ""
echo "////////////////////////////////////////"
echo "***** Filestore NFS 포트 설정 확인 *****"
IS_NULL=`sudo cat /etc/sysconfig/nfs | grep 2046`
if [[ -z $IS_NULL ]]; then
    echo "!! Check result !!"
    echo "No STATD_PORT 2046 setting in /etc/sysconfig/nfs"
else
    echo "OK"
fi
IS_NULL=`sudo cat /etc/modprobe.d/lock.conf | grep 4045`
if [[ -z $IS_NULL ]]; then
    echo "!! Check result !!"
    echo "No nlm_tcpport & nlm_udpport 4045 setting in /etc/modprobe.d/lock.conf"
else
    echo "OK"
fi
