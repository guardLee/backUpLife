#!/usr/bin/env bash
# copyrightⓒ 2022 All rights reserved by SungJae, Yun. (sjyun@cloudgram.com)

DATE=`date +%Y-%m-%d_%H:%M:%S`

sudo yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm
sudo yum -y install telnet wget nmon expect git unzip bind-utils
        

# sshd에서 password 로그인 허용
############### sshd_config ###################
#sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
echo ""
echo "////////////////////////////////////////"
echo "1. sshd에서 password 로그인 허용"
sudo sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config
sudo systemctl restart sshd
echo 'PasswordAuthentication Change Successed'

# sshd port change to 40022
############### sshd_config ###################
#sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
echo ""
echo "////////////////////////////////////////"
echo "2. sshd port change to 40022"
sudo sed -i 's/#Port 22/Port 40022/g' /etc/ssh/sshd_config
sudo systemctl restart sshd
echo 'sshd port Change Successed'

# SELINUX disable
############### SELINUX ###################
echo ""
echo "////////////////////////////////////////"
echo "3. SELINUX disable"
sudo sed -i 's/enforcing/disabled/g' /etc/selinux/config
sudo sed -i 's/enforcing/disabled/g' /etc/sysconfig/selinux
sudo setenforce 0
echo 'selinux service disabled.'

# firewall disable
############### firewalld ###################
echo ""
echo "////////////////////////////////////////"
echo "4. firewall disable"
sudo systemctl disable firewalld
sudo systemctl stop firewalld
echo 'firewall service disabled.'

# Timezone 수정 (Asia/Seoul)
############### Timezone ###################
echo ""
echo "////////////////////////////////////////"
echo "5. Timezone 수정 (Asia/Seoul)"
sudo timedatectl set-timezone Asia/Seoul
sudo timedatectl
echo 'timezone Change Successed'

# SWAP 사용 안함
############### Timezone ###################
echo ""
echo "////////////////////////////////////////"
echo "6. Disable SWAP"
IS_EXIST=`grep -w "vm.swappiness = 0" /etc/sysctl.conf | wc -l`
if [[ $IS_EXIST = 0 ]]; then
    echo "vm.swappiness = 0" | sudo tee -a /etc/sysctl.conf
    sudo sysctl -p
    sudo sysctl vm.swappiness
    echo 'Disabled SWAP'
else
    echo "Already exist."
fi

# Add sysadm user
############### Add sysadm user ###################
echo ""
echo "////////////////////////////////////////"
echo "7. sysadm 추가"
USER="sysadm"
PASSWORD="!dlatl00"
IS_EXIST=`grep -w "$USER" /etc/passwd | wc -l`

if [[ $IS_EXIST = 0 ]]; then
    echo "Adding user ID = $USER."
    sudo useradd -r -m $USER
    sudo usermod -G wheel $USER                      ## CentOS에서 sudo 권한 부여
    echo "ID/Password : $USER / !dlatl00"
expect <<EOF
spawn sudo passwd "$USER"
expect "New password:"
send "$PASSWORD\r";

expect "Retype new password:"
send "$PASSWORD\r";

expect eof 
EOF
exit
else
    echo "Aleady exist user ID = $USER."
fi

# Add saccadm user
############### Add saccadm user ###################
echo ""
echo "////////////////////////////////////////"
echo "8. saccadm 추가"
USER="saccadm"
PASSWORD="!admin0000"
IS_EXIST=`grep -w "$USER" /etc/passwd | wc -l`

if [[ $IS_EXIST = 0 ]]; then
    echo "Adding user ID = $USER."
    sudo useradd -r -m $USER
    sudo usermod -G wheel $USER                      ## CentOS에서 sudo 권한 부여
    echo "ID/Password : $USER / !admin0000"
expect <<EOF
spawn sudo passwd "$USER"
expect "New password:"
send "$PASSWORD\r";

expect "Retype new password:"
send "$PASSWORD\r";

expect eof 
EOF
exit
else
    echo "Aleady exist user ID = $USER."
fi